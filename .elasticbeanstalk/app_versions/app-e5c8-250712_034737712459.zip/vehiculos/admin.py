from django.contrib import admin
from .models import Vehiculo
admin.site.register(Vehiculo)
# Examen Rastreo

Instrucciones para correr localmente:

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Pruebas CURL:
```bash
# Login, insertar, actualizar, borrar usando cookies o token
```
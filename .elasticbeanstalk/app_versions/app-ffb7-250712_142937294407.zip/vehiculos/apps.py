from django.apps import AppConfig

class VehiculosConfig(AppConfig):
    name = 'vehiculos'